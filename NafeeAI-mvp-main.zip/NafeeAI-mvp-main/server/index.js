import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { GoogleGenerativeAI } from '@google/generative-ai'

const app = express()
app.use(cors())
app.use(express.json())

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)
const model = genAI.getGenerativeModel({ model: 'gemini-3.5-flash-lite' })

app.post('/api/treatment-plan', async (req, res) => {
  const { studentName, learningGap, studentStatus, recommendedAction } = req.body || {}
  if (!studentName || !learningGap) {
    return res.status(400).json({ error: 'studentName و learningGap مطلوبان' })
  }

  const prompt = `أنت مساعد تعليمي ذكي لمعلمي الرياضيات. أنشئ خطة علاج تعليمية أسبوعية مخصصة لطالب واحد.

سياق مهم يجب الالتزام به بدقة:
- المصدر الوحيد للمعلومات عن أداء الطالب هو الواجبات المرفوعة التي حللها الذكاء الاصطناعي (وليس أي اختبارات أو تقييمات سابقة).
- لا تذكري إطلاقاً كلمات مثل "الاختبارات السابقة" أو "اختبار" أو "تقييمات سابقة" أو أي بيانات تاريخية لم تُذكر في بيانات الطالب أدناه.
- اربطي حقل "reason" فقط بـ: مستوى الطالب في الواجبات المرفوعة، الأخطاء المكتشفة في تحليل إجاباته، الفجوة التعليمية المستخرجة من تلك الواجبات، حالة الطالب، والإجراء المقترح.
- مثال على الصياغة الصحيحة: "بناءً على مستوى الطالب في الواجبات المرفوعة وتحليل إجاباته، تظهر لديه فجوة في ..." — لا تستخدمي صياغات عن اختبارات أو تقييمات لم تُذكر.

أعد الرد بصيغة JSON فقط (بدون أي نص أو markdown خارج الـJSON) بالحقول التالية باللغة العربية:
{
  "learningGap": "وصف موجز للفجوة التعليمية",
  "reason": "سبب اقتراح هذه الخطة بناءً على أداء الطالب في الواجبات المرفوعة فقط",
  "goal": "الهدف العام من الخطة",
  "weeks": [
    { "week": 1, "title": "عنوان الأسبوع", "objective": "هدف هذا الأسبوع تحديداً", "activities": ["نشاط ١", "نشاط ٢"], "assessment": "طريقة قصيرة لتقييم هذا الأسبوع" }
  ]
}

قواعد مهمة:
- أنشئ ٤ إلى ٥ أسابيع حسب شدة الفجوة (فجوة بسيطة = ٤ أسابيع، فجوة أكبر أو أكثر من موضوع = ٥ أسابيع).
- يجب أن يكون التسلسل منطقياً ومتدرجاً:
  الأسبوع ١: أساسيات ومعالجة المفاهيم الناقصة.
  الأسبوع ٢: تدريب موجّه مع أمثلة محلولة.
  الأسبوع ٣: تطبيق مركّز على الفجوة تحديداً.
  الأسبوع ٤: تدريب مستقل شبه مستقل عن المعلم.
  الأسبوع ٥ (إن وُجد): تقييم نهائي وتثبيت المهارة.
- كل أسبوع يجب أن يحتوي على ٢-٣ أنشطة واقعية ومناسبة لطالب مدرسي (لا مبالغة في العدد أو الصعوبة).
- الأنشطة يجب أن تتطور تدريجياً باتجاه معالجة الفجوة، لا أن تكون قائمة عامة متكررة.
- خصصي المحتوى فعلياً لاسم الطالب وفجوته ومستوى أدائه، لا نصاً عاماً.

بيانات الطالب (المصدر الوحيد المسموح استخدامه):
- الاسم: ${studentName}
- الفجوة التعليمية المستخرجة من الواجبات المرفوعة: ${learningGap}
- الحالة: ${studentStatus || 'غير محددة'}
- الإجراء المقترح: ${recommendedAction || 'خطة علاجية'}`

  try {
    const result = await model.generateContent(prompt)
    const text = result.response.text().replace(/```json|```/g, '').trim()
    const plan = JSON.parse(text)
    res.json(plan)
  } catch (err) {
    console.error('Gemini error:', err)
    res.status(500).json({ error: 'تعذر إنشاء خطة العلاج، حاول مرة أخرى' })
  }
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`))