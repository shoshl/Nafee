import { useState } from 'react'
import Sidebar from './pages/Sidebar'
import Topbar from './pages/Topbar'
import Dashboard from './pages/Dashboard'
import UploadPage from './pages/UploadPage'
import StudentsPage from './pages/StudentsPage'
import ClassAnalyticsPage from './pages/ClassAnalyticsPage'
import TreatmentPlansPage from './pages/TreatmentPlansPage'

export type Page =
  | 'dashboard'
  | 'upload'
  | 'students'
  | 'analytics'
  | 'plans'
  | 'reports'
  | 'settings'

export default function App() {
  const [page, setPage] = useState<Page>('dashboard')
  const [search, setSearch] = useState('')

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg)', direction: 'rtl', fontFamily: 'Cairo, sans-serif' }}>
      <Sidebar current={page} onNav={setPage} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Topbar search={search} onSearch={setSearch} onNav={setPage} />
        <main style={{ flex: 1, overflowY: 'auto' }}>
          {page === 'dashboard' && <Dashboard onNav={setPage} />}
          {page === 'upload'     && <UploadPage onNav={setPage} />}
          {page === 'students'   && <StudentsPage onNav={setPage} />}
          {page === 'analytics'  && <ClassAnalyticsPage onNav={setPage} />}
          {page === 'plans'      && <TreatmentPlansPage />}
        </main>
      </div>
    </div>
  )
}