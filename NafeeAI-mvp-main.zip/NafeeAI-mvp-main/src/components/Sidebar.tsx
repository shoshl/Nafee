// This file is superseded by src/nafee/Sidebar.tsx
export default function Sidebar() { return null }
