import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import type { Page } from '../App'

interface Props { onNav: (p: Page, topic?: string) => void }

// 1. نظام ألوان الدرجة
const scoreC = (n: number) => n >= 75 ? '#15803d' : n >= 60 ? '#d97706' : '#dc2626'

// 2. نظام ألوان الحالات
const statusStyle = (st: string) => {
  switch (st) {
    case 'متفوق':    return { bg: '#f0fdf4', color: '#15803d' }
    case 'مستقر':    return { bg: '#fffbeb', color: '#d97706' }
    case 'يحتاج دعم': return { bg: '#fef2f2', color: '#dc2626' }
    default:         return { bg: '#f3f4f6', color: '#4b5563' }
  }
}

// 3. ألوان خطورة المواضيع
const sevColor = (s: string) =>
  s === 'حرج'    ? { bar: '#ef4444', badge: '#fef2f2', text: '#dc2626' } :
  s === 'متوسط'  ? { bar: '#f59e0b', badge: '#fffbeb', text: '#d97706' } :
                   { bar: '#15803d', badge: '#f0fdf4', text: '#15803d' }

const topics = [
  { t: 'العلاقات الزاوية',        m: 38, s: 17, sev: 'حرج'   },
  { t: 'تطابق المثلثات',          m: 44, s: 13, sev: 'حرج'   },
  { t: 'المعادلات التربيعية',      m: 51, s: 10, sev: 'متوسط' },
  { t: 'الكسور والأعداد المختلطة', m: 56, s: 8,  sev: 'متوسط' },
  { t: 'التفكير النسبي',          m: 62, s: 6,  sev: 'متوسط' },
  { t: 'الدوال الخطية',            m: 71, s: 4,  sev: 'جيد'   },
  { t: 'العمليات على الأعداد',     m: 83, s: 2,  sev: 'جيد'   },
  { t: 'ترتيب العمليات',          m: 89, s: 1,  sev: 'جيد'   },
]

const students = [
  { name: 'خالد محمد',        grade: 'الصف الثامن',           score: 44, status: 'يحتاج دعم', topics: ['العلاقات الزاوية', 'تطابق المثلثات'], gap: 'فهم العلاقات الزاوية وتطابق المثلثات', action: 'خطة علاجية' },
  { name: 'غيدا سعد',          grade: 'الصف الثامن',           score: 52, status: 'يحتاج دعم', topics: ['الكسور والأعداد المختلطة', 'المعادلات التربيعية'], gap: 'العمليات على الكسور والمعادلات التربيعية', action: 'خطة علاجية' },
  { name: 'خالد القحطاني',     grade: 'الصف الرابع الابتدائي',  score: 87, status: 'متفوق',    topics: ['التفكير النسبي'], gap: 'لا توجد فجوات واضحة', action: 'تحديات إضافية' },
  { name: 'عبدالعزيز المطيري', grade: 'الصف السادس الابتدائي',  score: 75, status: 'مستقر',    topics: ['الدوال الخطية'], gap: 'تطبيق الدوال الخطية', action: 'متابعة دورية' },
  { name: 'سارة العتيبي',       grade: 'الصف الأول الابتدائي',   score: 91, status: 'متفوق',    topics: [], gap: 'لا توجد فجوات واضحة', action: 'تحديات إضافية' },
  { name: 'نورة الدوسري',      grade: 'الصف الثاني الابتدائي',  score: 78, status: 'مستقر',    topics: ['العلاقات الزاوية'], gap: 'تطبيق العلاقات الزاوية', action: 'متابعة دورية' },
]

const barData = students.map(s => ({ name: s.name === 'خالد محمد' ? 'خالد م.' : s.name.split(' ')[0], score: s.score }))

const TT = ({ active, payload, label }: any) => active && payload?.length ? (
  <div style={{ background: '#111827', color: 'white', borderRadius: 8, padding: '6px 10px', fontSize: 12, fontFamily: 'Cairo, sans-serif' }}>
    <div>{label}</div><div style={{ color: '#4ade80', fontWeight: 700 }}>{payload[0].value}٪</div>
  </div>
) : null

const CustomBar = (props: any) => {
  const { x, y, width, height, value } = props
  return <rect x={x} y={y} width={width} height={height} rx={4} fill={value >= 75 ? '#15803d' : value >= 60 ? '#f59e0b' : '#ef4444'} />
}

export default function ClassAnalyticsPage({ onNav }: Props) {
  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto', fontFamily: 'Cairo, sans-serif', direction: 'rtl', textAlign: 'right' }}>
      
      {/* ── Top Layout Grid ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 18, marginBottom: 20 }}>

        {/* Topics Performance & Bar Chart */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Topics List */}
          <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e5e7eb', padding: '18px 20px', boxShadow: '0 1px 2px rgba(0,0,0,0.03)' }}>
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>أداء المواضيع</div>
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>مجالات التحسين المكتشفة — اضغطي على موضوع لإنشاء خطة علاج</div>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {topics.map(t => {
                const sc = sevColor(t.sev)
                return (
                  <button key={t.t} onClick={() => onNav('plans', t.t)} style={{ display: 'block', width: '100%', background: 'none', border: 'none', padding: 0, cursor: 'pointer', fontFamily: 'Cairo, sans-serif', textAlign: 'right' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4, alignItems: 'center' }}>
                      <span style={{ color: '#374151', fontWeight: 600 }}>{t.t}</span>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                        <span style={{ fontSize: 10, color: '#9ca3af' }}>{t.s} طالب</span>
                        <span style={{ fontSize: 10, fontWeight: 700, background: sc.badge, color: sc.text, borderRadius: 99, padding: '1px 7px' }}>{t.sev}</span>
                        <span style={{ fontWeight: 800, color: sc.text, fontSize: 12 }}>{t.m}٪</span>
                      </div>
                    </div>
                    <div style={{ height: 6, background: '#f3f4f6', borderRadius: 99 }}>
                      <div style={{ height: '100%', width: `${t.m}%`, background: sc.bar, borderRadius: 99 }} />
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Student Performance Bar Chart */}
          <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e5e7eb', padding: '18px 20px', boxShadow: '0 1px 2px rgba(0,0,0,0.03)' }}>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>أداء الطلاب</div>
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>درجات آخر واجب دراسي</div>
            </div>
            <ResponsiveContainer width="100%" height={170}>
              <BarChart data={barData} barCategoryGap="30%" margin={{ top: 4, right: 0, left: -24, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#9ca3af', fontFamily: 'Cairo, sans-serif' }} axisLine={false} tickLine={false} />
                <YAxis domain={[0,100]} tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <Tooltip content={<TT />} cursor={{ fill: '#f9fafb' }} />
                <Bar dataKey="score" shape={<CustomBar />} />
              </BarChart>
            </ResponsiveContainer>
          </div>

        </div>

        {/* Sidebar Summary */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e5e7eb', padding: '18px 20px', boxShadow: '0 1px 2px rgba(0,0,0,0.03)' }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: '#111827', marginBottom: 16 }}>ملخص الفصل</div>
            {[
              { l: 'نسبة الفصل العامة', v: '٧١٪',      c: '#374151' },
              { l: 'يحتاجون دعم (< ٦٠٪)', v: '٣ طلاب',  c: '#dc2626' },
              { l: 'متميزون (> ٨٥٪)',   v: '٢ طلاب',  c: '#15803d' },
              { l: 'مجالات حرجة',       v: '٢',        c: '#dc2626' },
            ].map((m, idx, arr) => (
              <div key={m.l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, paddingBottom: 10, marginBottom: idx < arr.length - 1 ? 10 : 0, borderBottom: idx < arr.length - 1 ? '1px solid #f3f4f6' : 'none' }}>
                <span style={{ color: '#6b7280' }}>{m.l}</span>
                <span style={{ fontWeight: 800, color: m.c }}>{m.v}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* ── Student Details Table ── */}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e5e7eb', overflow: 'hidden', boxShadow: '0 1px 2px rgba(0,0,0,0.03)' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid #f3f4f6', background: '#fafafa' }}>
          <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>تفاصيل مستوى الطلاب</div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #f3f4f6', background: '#fafafa' }}>
                {['الطالب', 'الصف', 'النسبة', 'الحالة', 'مجالات التحسين', 'الفجوة الحالية', 'الإجراء المقترح'].map(h => (
                  <th key={h} style={{ textAlign: 'right', padding: '10px 16px', fontSize: 11, fontWeight: 700, color: '#9ca3af' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {students.map((s, i) => {
                const st = statusStyle(s.status)
                return (
                  <tr 
                    key={i} 
                    onClick={() => onNav('students')}
                    style={{ borderBottom: i < students.length - 1 ? '1px solid #f3f4f6' : 'none', cursor: 'pointer', transition: 'background 0.15s' }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#fafafa'}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}
                  >
                    <td style={{ padding: '12px 16px', fontWeight: 700, color: '#111827' }}>{s.name}</td>
                    
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ fontSize: 11, fontWeight: 600, color: '#4b5563', background: '#f3f4f6', borderRadius: 6, padding: '3px 8px', whiteSpace: 'nowrap' }}>
                        {s.grade}
                      </span>
                    </td>

                    <td style={{ padding: '12px 16px', fontWeight: 800, color: scoreC(s.score) }}>{s.score}٪</td>
                    
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ fontSize: 10, fontWeight: 700, background: st.bg, color: st.color, borderRadius: 99, padding: '3px 8px', whiteSpace: 'nowrap', display: 'inline-block' }}>
                        {s.status}
                      </span>
                    </td>
                    
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                        {s.topics.length === 0
                          ? <span style={{ color: '#9ca3af', fontSize: 11 }}>لا يوجد</span>
                          : s.topics.slice(0, 2).map(t => (
                            <span key={t} style={{ fontSize: 10, background: '#fffbeb', color: '#d97706', borderRadius: 99, padding: '2px 7px', fontWeight: 700 }}>{t}</span>
                          ))}
                        {s.topics.length > 2 && <span style={{ fontSize: 10, color: '#9ca3af' }}>+{s.topics.length - 2}</span>}
                      </div>
                    </td>

                    <td style={{ padding: '12px 16px', color: '#374151' }}>{s.gap}</td>
                    
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ fontSize: 11, fontWeight: 600, color: st.color, background: st.bg, borderRadius: 6, padding: '3px 8px', whiteSpace: 'nowrap', display: 'inline-block' }}>
                        {s.action}
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  )
}