import React from 'react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts'
import type { Page } from '../App'

interface Props { onNav: (p: Page) => void }

/* ── Minimal SVG Icons ── */
const Icons = {
  Users: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  ),
  Calendar: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  ),
  School: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
      <path d="M6 12v5c3 3 9 3 12 0v-5" />
    </svg>
  ),
  BookOpen: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  ),
  Bot: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="11" width="18" height="10" rx="2" />
      <circle cx="12" cy="5" r="2" />
      <path d="M12 7v4" />
      <line x1="8" y1="16" x2="8" y2="16" />
      <line x1="16" y1="16" x2="16" y2="16" />
    </svg>
  ),
  Triangle: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  ),
  Star: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  ),
  Clock: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  ),
  ArrowLeft: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="19" y1="12" x2="5" y2="12" />
      <polyline points="12 19 5 12 12 5" />
    </svg>
  )
}

/* ── Stats Data ── */
const stats = [
  { label: 'إجمالي عدد الطلاب', value: '٢٨', delta: '+٢ هذا الأسبوع', pos: true,  icon: Icons.Users },
  { label: 'الفصل الدراسي',     value: 'الثاني', delta: 'عام ١٤٤٧ هـ',     pos: null,  icon: Icons.Calendar },
  { label: 'عدد الصفوف',        value: '٤',     delta: 'صفوف دراسية',    pos: null,  icon: Icons.School },
  { label: 'المواد',            value: '٣',     delta: 'رياضيات، علوم، عربية', pos: null, icon: Icons.BookOpen },
]

const progressData = [
  { w: 'أ١', v: 62 }, { w: 'أ٢', v: 68 }, { w: 'أ٣', v: 71 },
  { w: 'أ٤', v: 74 }, { w: 'أ٥', v: 70 }, { w: 'أ٦', v: 78 },
  { w: 'أ٧', v: 82 }, { w: 'أ٨', v: 85 },
]

const pieData = [
  { name: 'متقن',      value: 12, color: '#15803d' },
  { name: 'في التطور', value: 10, color: '#f59e0b' },
  { name: 'في خطر',    value: 6,  color: '#ef4444' },
]

const recs = [
  { icon: Icons.Triangle, t: 'تعزيز العلوم', d: 'النسبة العامة ٦٦٪ في العلوم أقل من المستهدف. يُنصح بتخصيص جلستين أسبوعياً للمراجعة.', pr: 'عالية', pc: '#dc2626' },
  { icon: Icons.Star, t: 'نجاح اللغة العربية', d: 'أعلى من النسبة المستهدفة. حافظي على هذا المستوى بتنويع أنشطة القراءة.', pr: 'ملاحظة', pc: '#15803d' },
  { icon: Icons.Clock, t: 'إدارة الوقت', d: 'طالبان تأخرا في تسليم الواجبات الأسبوع الماضي. يُنصح بالتذكير اليومي.', pr: 'متوسطة', pc: '#d97706' },
]

/* ── Helpers ── */
const TT = ({ active, payload, label }: any) => active && payload?.length ? (
  <div style={{ background: '#111827', color: 'white', borderRadius: 8, padding: '6px 10px', fontSize: 12, fontFamily: 'Cairo, sans-serif' }}>
    <div>{label}</div><div style={{ color: '#4ade80', fontWeight: 700 }}>{payload[0].value}٪</div>
  </div>
) : null

/* ── Card Shell ── */
const Card = ({ children, style = {} }: { children: React.ReactNode; style?: React.CSSProperties }) => (
  <div style={{ background: '#ffffff', borderRadius: 12, border: '1px solid #e5e7eb', boxShadow: '0 1px 2px rgba(0,0,0,0.03)', ...style }}>
    {children}
  </div>
)

export default function Dashboard({ onNav }: Props) {
  return (
    <div style={{ padding: '28px 32px', maxWidth: 1200, margin: '0 auto', direction: 'rtl', textAlign: 'right' }}>

      {/* ── Stat Cards ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 22 }}>
        {stats.map(s => {
          const IconComponent = s.icon
          return (
            <Card key={s.label} style={{ padding: '18px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div style={{ width: 34, height: 34, borderRadius: 8, background: '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#374151' }}>
                  <IconComponent />
                </div>
                {s.pos === true && <span style={{ fontSize: 12, color: '#16a34a', fontWeight: 700 }}></span>}
                {s.pos === false && <span style={{ fontSize: 12, color: '#dc2626', fontWeight: 700 }}>-١ ↓</span>}
              </div>

              <div style={{ fontSize: 12, color: '#6b7280', fontWeight: 600, marginBottom: 4 }}>
                {s.label}
              </div>

              <div style={{ fontSize: 26, fontWeight: 800, color: '#111827', lineHeight: 1.1 }}>
                {s.value}
              </div>

              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 6, fontWeight: 500 }}>
                {s.delta}
              </div>
            </Card>
          )
        })}
      </div>

      {/* ── Level & AI Insights Row ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 0.9fr', gap: 18, marginBottom: 22 }}>

        {/* مستوى الصفوف */}
        <Card style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>مستوى الصفوف</div>
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>نظرة سريعة على متوسط أداء الصفوف الدراسيّة</div>
            </div>
            <button onClick={() => onNav('analytics')} style={{ background: 'none', border: 'none', color: '#15803d', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'Cairo, sans-serif' }}>عرض التفاصيل</button>
          </div>
          <ResponsiveContainer width="100%" height={195}>
            <AreaChart data={progressData} margin={{ top: 4, right: 0, left: -24, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
              <XAxis dataKey="w" tick={{ fontSize: 10, fill: '#9ca3af', fontFamily: 'Cairo, sans-serif' }} axisLine={false} tickLine={false} />
              <YAxis domain={[0,100]} tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
              <Tooltip content={<TT />} cursor={{ stroke: '#15803d', strokeWidth: 1 }} />
              <Area type="monotone" dataKey="v" stroke="#15803d" strokeWidth={2} fill="#15803d" fillOpacity={0.12} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* توصيات الذكاء الاصطناعي */}
        <Card style={{ padding: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#374151' }}>
              <Icons.Bot />
            </div>
            <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>توصيات الذكاء الاصطناعي</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {recs.map(r => {
              const ItemIcon = r.icon
              return (
                <div key={r.t} style={{ background: '#f9fafb', border: '1px solid #f3f4f6', borderRadius: 10, padding: '12px 14px', display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                  <div style={{ color: r.pc, marginTop: 2 }}>
                    <ItemIcon />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                      <div style={{ fontSize: 12, fontWeight: 800, color: '#111827' }}>{r.t}</div>
                      <span style={{ fontSize: 10, fontWeight: 700, background: `${r.pc}15`, color: r.pc, borderRadius: 99, padding: '2px 8px' }}>{r.pr}</span>
                    </div>
                    <div style={{ fontSize: 11, color: '#6b7280', lineHeight: 1.5 }}>{r.d}</div>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>
      </div>

      {/* ── Flipped Learning Gaps ── */}
      <Card style={{ padding: 22, marginBottom: 22 }}>
        <div style={{ fontSize: 14, fontWeight: 800, color: '#111827', marginBottom: 4 }}>فجوات التعلم</div>
        <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 16 }}>توزيع ٢٨ طالباً</div>
        <ResponsiveContainer width="100%" height={140}>
          <PieChart>
            <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={3} dataKey="value" stroke="none">
              {pieData.map((d, i) => <Cell key={i} fill={d.color} />)}
            </Pie>
            <Tooltip formatter={(v) => [`${v} طلاب`]} contentStyle={{ fontFamily: 'Cairo, sans-serif', borderRadius: 8, border: 'none', boxShadow: '0 4px 16px rgba(0,0,0,0.08)', fontSize: 12 }} />
          </PieChart>
        </ResponsiveContainer>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 24, marginTop: 4 }}>
          {pieData.map(d => (
            <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: d.color }} />
              <span style={{ fontSize: 12, color: '#374151', fontWeight: 600 }}>{d.name}</span>
              <span style={{ fontSize: 12, fontWeight: 800, color: '#111827' }}>{d.value}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* ── CTA ── */}
      <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 12, padding: '20px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#111827' }}>فجوات تعلم جاهزة للمعالجة</div>
          <p style={{ fontSize: 13, color: '#6b7280', marginTop: 5, lineHeight: 1.6 }}>٦ طلاب يحتاجون خطط تعلم مخصصة — استكشفي تحليل الفصل لاختيار فجوة وإنشاء خطة علاج بالذكاء الاصطناعي</p>
        </div>
        <button onClick={() => onNav('analytics')} style={{ flexShrink: 0, background: '#15803d', color: 'white', border: 'none', borderRadius: 8, padding: '11px 22px', fontFamily: 'Cairo, sans-serif', fontSize: 13, fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
          <span>استكشاف الفجوات</span>
          <Icons.ArrowLeft />
        </button>
      </div>

    </div>
  )
}