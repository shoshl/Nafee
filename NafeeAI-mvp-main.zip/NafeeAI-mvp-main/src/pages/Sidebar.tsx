import { LayoutGrid, Upload, Users, BarChart3, Sparkles, Settings } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import type { Page } from '../App'

interface Props { current: Page; onNav: (p: Page) => void }

const nav: { id: Page; ar: string; icon: LucideIcon }[] = [
  { id: 'dashboard', ar: 'الرئيسية',         icon: LayoutGrid },
  { id: 'upload',    ar: 'رفع الواجبات',     icon: Upload },
  { id: 'students',  ar: 'الطلاب',           icon: Users },
  { id: 'analytics', ar: 'تحليل الفصل',      icon: BarChart3 },
  { id: 'plans',     ar: 'خطط التعلم',       icon: Sparkles },
]

export default function Sidebar({ current, onNav }: Props) {
  return (
    <aside style={{ width: 220, flexShrink: 0, background: '#ffffff', borderLeft: '1px solid var(--border)', display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* Logo */}
      <div style={{ padding: '22px 18px 18px', borderBottom: '1px solid var(--border-light)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 38, height: 38, borderRadius: 12, background: 'linear-gradient(135deg,#15803d 0%,#22c55e 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span style={{ color: 'white', fontWeight: 900, fontSize: 17 }}>ن</span>
          </div>
          <div>
            <div style={{ fontWeight: 900, fontSize: 18, color: '#15803d', lineHeight: 1 }}>نفيع</div>
            <div style={{ fontSize: 10, color: '#9ca3af', fontWeight: 600, letterSpacing: 0.5 }}>مساعد المعلم الذكي</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '10px 10px', overflowY: 'auto' }}>
        {nav.map(({ id, ar, icon: Icon }) => {
          const on = current === id
          return (
            <button key={id} onClick={() => onNav(id)}
              style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', marginBottom: 2, borderRadius: 11, border: 'none', borderRight: `3px solid ${on ? '#15803d' : 'transparent'}`, background: on ? '#f0fdf4' : 'transparent', color: on ? '#15803d' : '#6b7280', fontFamily: 'Cairo, sans-serif', fontSize: 13, fontWeight: on ? 700 : 500, cursor: 'pointer', textAlign: 'right', transition: 'all 0.13s' }}
              onMouseEnter={e => { if (!on) { (e.currentTarget as HTMLElement).style.background = '#f9fafb'; (e.currentTarget as HTMLElement).style.color = '#111827' } }}
              onMouseLeave={e => { if (!on) { (e.currentTarget as HTMLElement).style.background = 'transparent'; (e.currentTarget as HTMLElement).style.color = '#6b7280' } }}>
              <Icon size={17} strokeWidth={on ? 2.4 : 2} style={{ flexShrink: 0 }} />
              {ar}
              {id === 'plans' && (
                <span style={{ marginRight: 'auto', fontSize: 9, fontWeight: 800, background: '#dcfce7', color: '#15803d', borderRadius: 99, padding: '2px 6px' }}>AI</span>
              )}
            </button>
          )
        })}
      </nav>

      {/* Teacher card */}
      <div style={{ margin: '0 10px 14px', borderRadius: 12, background: 'linear-gradient(135deg,#f0fdf4,#dcfce7)', border: '1px solid #bbf7d0', padding: '12px 14px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'linear-gradient(135deg,#15803d,#22c55e)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>ف</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>فاطمة العمري</div>
            <div style={{ fontSize: 11, color: '#6b7280' }}>معلمة رياضيات </div>
          </div>
        </div>
        <button style={{ marginTop: 9, width: '100%', background: 'transparent', border: '1px solid #bbf7d0', borderRadius: 8, color: '#6b7280', fontFamily: 'Cairo, sans-serif', fontSize: 11, fontWeight: 600, padding: '5px', cursor: 'pointer' }}>
          تسجيل الخروج
        </button>
      </div>
    </aside>
  )
}