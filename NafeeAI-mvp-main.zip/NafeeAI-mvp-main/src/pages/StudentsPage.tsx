import { useState } from 'react'
import type { Page } from '../App'

interface Props { onNav: (p: Page) => void }

interface Student {
  name: string
  init: string
  grade: string
  status: 'متميز' | 'على المسار' | 'في تطور' | 'في خطر'
  tasksDone: string
}

const all: Student[] = [
  { name: 'سارة العتيبي',    init: 'س', grade: 'الصف الثامن (أ)', status: 'متميز',    tasksDone: '٥/٥' },
  { name: 'خالد القحطاني',   init: 'خ', grade: 'الصف الثامن (أ)', status: 'على المسار', tasksDone: '٤/٥' },
  { name: 'نورة الدوسري',    init: 'ن', grade: 'الصف الثامن (ب)', status: 'على المسار', tasksDone: '٥/٥' },
  { name: 'عبدالعزيز المطيري', init: 'ع', grade: 'الصف الثامن (أ)', status: 'على المسار', tasksDone: '٤/٥' },
  { name: 'ريم الشهري',       init: 'ر', grade: 'الصف الثامن (ج)', status: 'في تطور',   tasksDone: '٣/٥' },
  { name: 'فيصل الحربي',      init: 'ف', grade: 'الصف الثامن (ب)', status: 'في تطور',   tasksDone: '٣/٥' },
  { name: 'خالد محمد',       init: 'خ', grade: 'الصف الثامن (أ)', status: 'في خطر',    tasksDone: '١/٥' },
  { name: 'غيدا سعد',        init: 'غ', grade: 'الصف الثامن (ج)', status: 'في خطر',    tasksDone: '١/٥' },
  { name: 'احمد محمد',       init: 'ا', grade: 'الصف الثامن (أ)', status: 'على المسار', tasksDone: '٥/٥' },
  { name: 'علياء الغامدي',    init: 'ع', grade: 'الصف الثامن (ب)', status: 'على المسار', tasksDone: '٤/٥' },
  { name: 'ليلى الشهري',     init: 'ل', grade: 'الصف الثامن (ج)', status: 'في تطور',   tasksDone: '٢/٥' },
  { name: 'محمد العتيبي',    init: 'م', grade: 'الصف الثامن (أ)', status: 'في خطر',    tasksDone: '١/٥' },
]

type F = 'الكل' | 'في خطر' | 'في تطور' | 'على المسار' | 'متميز'
type ViewMode = 'grid' | 'list'

const badge = (s: string) =>
  s === 'متميز'    ? { bg: '#f0fdf4', c: '#15803d', dot: '#15803d' } :
  s === 'على المسار' ? { bg: '#eff6ff', c: '#2563eb', dot: '#2563eb' } :
  s === 'في تطور'  ? { bg: '#fffbeb', c: '#d97706', dot: '#f59e0b' } :
                     { bg: '#fef2f2', c: '#dc2626', dot: '#ef4444' }

export default function StudentsPage({ onNav }: Props) {
  const [q, setQ]               = useState('')
  const [f, setF]               = useState<F>('الكل')
  const [viewMode, setViewMode] = useState<ViewMode>('grid')

  const handleNotifyParent = (e: React.MouseEvent, student: Student) => {
    e.stopPropagation()
    alert(`تم إرسال إشعار إلى ولي أمر الطالب (${student.name}) بنجاح`)
  }

  const shown = all.filter(s =>
    s.name.includes(q) &&
    (f === 'الكل' || s.status === f)
  )

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto', fontFamily: 'Cairo, sans-serif' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 900, color: '#0d1f15', margin: 0 }}>الطلاب</h1>
        </div>
        <button style={{ background: '#15803d', color: 'white', border: 'none', borderRadius: 11, padding: '10px 20px', fontFamily: 'Cairo, sans-serif', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>
          + إضافة طالب
        </button>
      </div>

      {/* Filters + View Switcher */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center', flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '8px 12px', flex: '1 1 200px', maxWidth: 260 }}>
            <input type="text" placeholder="ابحث باسم الطالب…" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1, background: 'none', border: 'none', outline: 'none', fontFamily: 'Cairo, sans-serif', fontSize: 13, color: '#111827', direction: 'rtl' }} />
          </div>
          {(['الكل', 'في خطر', 'في تطور', 'على المسار', 'متميز'] as F[]).map(opt => (
            <button key={opt} onClick={() => setF(opt)} style={{ padding: '8px 16px', borderRadius: 10, border: `1.5px solid ${f === opt ? '#15803d' : 'var(--border)'}`, background: f === opt ? '#15803d' : '#fff', color: f === opt ? 'white' : '#6b7280', fontFamily: 'Cairo, sans-serif', fontSize: 12, fontWeight: 700, cursor: 'pointer', transition: 'all 0.13s' }}>
              {opt}
            </button>
          ))}
        </div>

        {/* أزرار التحكم بطريقة العرض */}
        <div style={{ display: 'flex', background: '#e5e7eb', borderRadius: 10, padding: 3, gap: 2 }}>
          <button
            onClick={() => setViewMode('grid')}
            title="عرض شبكي"
            style={{
              border: 'none',
              background: viewMode === 'grid' ? '#fff' : 'transparent',
              color: viewMode === 'grid' ? '#15803d' : '#6b7280',
              borderRadius: 8,
              padding: '6px 12px',
              fontSize: 14,
              cursor: 'pointer',
              fontWeight: 700,
              boxShadow: viewMode === 'grid' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
              transition: 'all 0.15s'
            }}>
            ▦
          </button>
          <button
            onClick={() => setViewMode('list')}
            title="عرض قائمة"
            style={{
              border: 'none',
              background: viewMode === 'list' ? '#fff' : 'transparent',
              color: viewMode === 'list' ? '#15803d' : '#6b7280',
              borderRadius: 8,
              padding: '6px 12px',
              fontSize: 14,
              cursor: 'pointer',
              fontWeight: 700,
              boxShadow: viewMode === 'list' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
              transition: 'all 0.15s'
            }}>
            ☰
          </button>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: 16 }}>
          {shown.map(s => {
            const b = badge(s.status)
            return (
              <div key={s.name} onClick={() => onNav('analytics')} style={{ background: '#fff', borderRadius: 18, border: '1px solid var(--border)', padding: '20px 18px', cursor: 'pointer', transition: 'all 0.15s' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = '#bbf7d0'; (e.currentTarget as HTMLElement).style.boxShadow = '0 6px 24px rgba(21,128,61,0.09)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLElement).style.boxShadow = 'none' }}>

                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 16 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                    <div style={{ width: 44, height: 44, borderRadius: 13, background: b.bg, color: b.c, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900, fontSize: 18, flexShrink: 0 }}>{s.init}</div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>{s.name}</div>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 700, background: b.bg, color: b.c, borderRadius: 99, padding: '2px 8px', marginTop: 3 }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: b.dot, display: 'inline-block' }} />
                        {s.status}
                      </div>
                    </div>
                  </div>
                </div>

                <div style={{ background: '#f9fafb', borderRadius: 12, padding: '12px', marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 12, color: '#6b7280' }}>الصف:</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: '#374151' }}>{s.grade}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: 12, color: '#6b7280' }}>إنجاز الواجبات:</span>
                    <span style={{ fontSize: 13, fontWeight: 800, color: '#111827' }}>{s.tasksDone}</span>
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 8 }}>
                  <button style={{ flex: 1, background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 10, color: '#15803d', fontFamily: 'Cairo, sans-serif', fontSize: 12, fontWeight: 700, padding: '9px', cursor: 'pointer' }}>
                    عرض التحليل ←
                  </button>
                  <button onClick={(e) => handleNotifyParent(e, s)} style={{ background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 10, color: '#374151', fontFamily: 'Cairo, sans-serif', fontSize: 12, fontWeight: 700, padding: '9px 12px', cursor: 'pointer', whiteSpace: 'nowrap' }}>
                    إشعار ولي الأمر
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'right' }}>
            <thead>
              <tr style={{ background: '#fafafa', borderBottom: '1px solid var(--border)', fontSize: 12, color: '#6b7280' }}>
                <th style={{ padding: '14px 18px' }}>الطالب</th>
                <th style={{ padding: '14px 18px' }}>الصف</th>
                <th style={{ padding: '14px 18px' }}>الحالة</th>
                <th style={{ padding: '14px 18px' }}>إنجاز الواجبات</th>
                <th style={{ padding: '14px 18px', textAlign: 'left' }}>خيارات</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((s, idx) => {
                const b = badge(s.status)
                return (
                  <tr key={s.name} onClick={() => onNav('analytics')} style={{ borderBottom: idx < shown.length - 1 ? '1px solid #f3f4f6' : 'none', cursor: 'pointer', transition: 'background 0.1s' }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#f0fdf4'}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = '#fff'}>
                    <td style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 34, height: 34, borderRadius: 10, background: b.bg, color: b.c, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900, fontSize: 14 }}>{s.init}</div>
                      <span style={{ fontSize: 13, fontWeight: 800, color: '#111827' }}>{s.name}</span>
                    </td>
                    <td style={{ padding: '14px 18px', fontSize: 13, fontWeight: 600, color: '#4b5563' }}>{s.grade}</td>
                    <td style={{ padding: '14px 18px' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 700, background: b.bg, color: b.c, borderRadius: 99, padding: '2px 8px' }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: b.dot }} />
                        {s.status}
                      </span>
                    </td>
                    <td style={{ padding: '14px 18px', fontSize: 13, fontWeight: 700, color: '#111827' }}>{s.tasksDone}</td>
                    <td style={{ padding: '14px 18px', textAlign: 'left' }}>
                      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                        <button style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, color: '#15803d', fontFamily: 'Cairo, sans-serif', fontSize: 11, fontWeight: 700, padding: '6px 12px', cursor: 'pointer' }}>
                          التحليل ←
                        </button>
                        <button onClick={(e) => handleNotifyParent(e, s)} style={{ background: '#f3f4f6', border: '1px solid #e5e7eb', borderRadius: 8, color: '#374151', fontFamily: 'Cairo, sans-serif', fontSize: 11, fontWeight: 700, padding: '6px 10px', cursor: 'pointer' }}>
                          إشعار
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {shown.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#9ca3af' }}>
          <div style={{ fontSize: 14 }}>لا يوجد طلاب بهذا البحث</div>
        </div>
      )}
    </div>
  )
}