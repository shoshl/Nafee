import type { Page } from '../App'

interface Props { search: string; onSearch: (v: string) => void; onNav: (p: Page) => void }

export default function Topbar({ search, onSearch, onNav }: Props) {
  return (
    <header style={{ background: '#ffffff', borderBottom: '1px solid var(--border)', padding: '0 28px', height: 62, display: 'flex', alignItems: 'center', gap: 16, flexShrink: 0, position: 'sticky', top: 0, zIndex: 30 }}>
      {/* Welcome */}
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 17, fontWeight: 800, color: '#0d1f15' }}>مرحباً، فاطمة 👋</div>
        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1 }}>   الأربعاء، ٦ أغسطس ٢٠٢٦</div>
      </div>
    </header>
  )
}
