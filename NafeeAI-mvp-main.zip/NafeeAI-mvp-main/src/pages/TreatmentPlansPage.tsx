import { useState, useEffect } from 'react'

interface Props { selectedTopic?: string | null }

interface AiWeek {
  week: number
  title: string
  objective: string
  activities: string[]
  assessment: string
}

interface AiPlan {
  learningGap: string
  reason: string
  goal: string
  weeks: AiWeek[]
}

const API_BASE = (import.meta as any).env?.VITE_API_BASE || ''

const plans = [
  {
    student: 'خالد محمد', init: 'خ', topics: ['العلاقات الزاوية', 'تطابق المثلثات'], score: 44, urgent: true,
    weeks: [
      { w: 'الأسبوع ١', theme: 'أسس الزوايا',
        days: [
          { d: 'الاثنين', t: 'فيديو: أنواع الزوايا', type: '🎬', done: false },
          { d: 'الثلاثاء', t: 'شرح بصري: المتوازيات والمستقيم القاطع', type: '🖼', done: false },
          { d: 'الخميس', t: 'تطبيق: ١٢ تمريناً مختلطاً', type: '💻', done: false },
        ]},
      { w: 'الأسبوع ٢', theme: 'تطابق المثلثات',
        days: [
          { d: 'الاثنين', t: 'معايير تطابق المثلثات', type: '🎬', done: false },
          { d: 'الأربعاء', t: 'برهان ذو عمودين', type: '🖼', done: false },
        ]},
    ],
  },
  {
    student: 'غيدا سعد', init: 'ب', topics: ['الكسور', 'المعادلات التربيعية'], score: 52, urgent: true,
    weeks: [
      { w: 'الأسبوع ١', theme: 'الكسور والأعداد المختلطة',
        days: [
          { d: 'الاثنين', t: 'فيديو: جمع وطرح الكسور', type: '🎬', done: false },
          { d: 'الثلاثاء', t: 'تطبيق: ٨ مسائل متدرجة', type: '💻', done: false },
        ]},
    ],
  },
]

const typeC: Record<string, { bg: string; c: string }> = {
  '🎬': { bg: '#ede9fe', c: '#7c3aed' },
  '🖼': { bg: '#f0fdfa', c: '#0d9488' },
  '💻': { bg: '#fffbeb', c: '#d97706' },
  '✅': { bg: '#f0fdf4', c: '#15803d' },
}

export default function TreatmentPlansPage({ selectedTopic }: Props) {
  const [sel, setSel] = useState(0)
  const [done, setDone] = useState<Set<string>>(new Set())
  const [gen, setGen] = useState(false)
  const [genDone, setGenDone] = useState(false)
  const [aiPlan, setAiPlan] = useState<AiPlan | null>(null)
  const [aiLoading, setAiLoading] = useState(false)
  const [aiError, setAiError] = useState<string | null>(null)

  useEffect(() => {
    if (!selectedTopic) return
    const idx = plans.findIndex(p => p.topics.some(pt => selectedTopic.includes(pt) || pt.includes(selectedTopic)))
    if (idx >= 0) setSel(idx)
  }, [selectedTopic])

  // تبديل الطالب يمسح الخطة السابقة فقط، ولا يستدعي Gemini تلقائياً
  useEffect(() => {
    setAiPlan(null)
    setAiError(null)
    setGenDone(false)
  }, [sel])

  // يُستدعى فقط عند ضغط المعلمة على زر "إنشاء خطة تلقائية"
  const generate = () => {
    const p = plans[sel]
    setAiPlan(null)
    setAiError(null)
    setGen(true)
    setAiLoading(true)
    fetch(`${API_BASE}/api/treatment-plan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        studentName: p.student,
        learningGap: p.topics.join('، '),
        studentStatus: p.urgent ? 'يحتاج دعم' : 'مستقر',
        recommendedAction: 'خطة علاجية',
      }),
    })
      .then(async r => { if (!r.ok) throw new Error((await r.json()).error || 'فشل الطلب'); return r.json() })
      .then(res => { setAiPlan(res); setGenDone(true) })
      .catch(() => setAiError('تعذر إنشاء خطة العلاج بالذكاء الاصطناعي، حاولي مرة أخرى'))
      .finally(() => { setAiLoading(false); setGen(false) })
  }

  const plan = plans[sel]
  const total = aiPlan?.weeks?.reduce((a, w) => a + w.activities.length, 0) ?? 0
  const comp  = aiPlan?.weeks?.reduce((a, w, wi) => a + w.activities.filter((_, ai) => done.has(`${sel}-${wi}-${ai}`)).length, 0) ?? 0

  const toggle = (key: string) => setDone(p => { const n = new Set(p); n.has(key) ? n.delete(key) : n.add(key); return n })

  return (
    <div style={{ padding: '28px 32px', maxWidth: 960, margin: '0 auto', fontFamily: 'Cairo, sans-serif' }}>
      <style>{`@keyframes spin { to { transform: rotate(360deg) } } .spin { animation: spin 0.8s linear infinite }`}</style>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 900, color: '#0d1f15', margin: '0 0 5px' }}>خطط العلاج بالذكاء الاصطناعي</h1>
          <p style={{ fontSize: 13, color: '#6b7280', margin: 0 }}>خطط أسبوعية مخصصة لكل طالب بناءً على تحليل أدائه</p>
        </div>
        <button onClick={generate} style={{ background: gen ? '#e5e7eb' : 'linear-gradient(135deg,#15803d,#22c55e)', color: gen ? '#9ca3af' : 'white', border: 'none', borderRadius: 12, padding: '11px 20px', fontFamily: 'Cairo, sans-serif', fontSize: 13, fontWeight: 700, cursor: 'pointer', boxShadow: gen ? 'none' : '0 4px 14px rgba(21,128,61,0.25)', transition: 'all 0.2s' }}>
          {gen ? 'جارٍ الإنشاء…' : genDone ? '✓ تم الإنشاء' : '✦ إنشاء خطط تلقائية'}
        </button>
      </div>

      {selectedTopic && (
        <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 12, padding: '10px 16px', marginBottom: 18, fontSize: 12, color: '#15803d', fontWeight: 700 }}>
          ✦ تم إنشاء هذه الخطة استناداً إلى فجوة التعلم: {selectedTopic}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 18 }}>
        {/* Student list */}
        <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)', alignSelf: 'start' }}>
          <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--border-light)', fontSize: 11, fontWeight: 700, color: '#9ca3af', background: '#fafafa' }}>الطلاب ({plans.length})</div>
          {plans.map((p, i) => (
            <button key={i} onClick={() => setSel(i)} style={{ width: '100%', padding: '12px 14px', border: 'none', borderRight: `3px solid ${sel === i ? '#15803d' : 'transparent'}`, background: sel === i ? '#f0fdf4' : 'transparent', cursor: 'pointer', textAlign: 'right', fontFamily: 'Cairo, sans-serif', display: 'flex', alignItems: 'center', gap: 9 }}>
              <div style={{ width: 30, height: 30, borderRadius: '50%', background: p.urgent ? '#fee2e2' : '#f0fdf4', color: p.urgent ? '#dc2626' : '#15803d', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, flexShrink: 0 }}>{p.init}</div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: sel === i ? '#15803d' : '#374151' }}>{p.student}</div>
                <div style={{ fontSize: 10, color: p.urgent ? '#dc2626' : '#9ca3af' }}>{p.topics.length} فجوات تعليمية</div>
              </div>
            </button>
          ))}
        </div>

        {/* Plan detail */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Header */}
          <div style={{ background: '#fff', borderRadius: 18, border: '1px solid var(--border)', padding: '20px 22px', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 16, fontWeight: 900, color: '#111827' }}>{plan.student}</div>
              <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 2 }}>فجوات التعلم: {plan.topics.join('، ')}</div>
            </div>
            {/* Progress */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#6b7280', marginBottom: 6 }}>
                  <span>تقدم الخطة</span>
                  <span style={{ color: '#15803d', fontWeight: 700 }}>{comp}/{total} جلسات</span>
                </div>
                <div style={{ height: 8, background: '#f3f4f6', borderRadius: 99 }}>
                  <div style={{ height: '100%', width: `${total ? (comp/total)*100 : 0}%`, background: 'linear-gradient(90deg,#15803d,#22c55e)', borderRadius: 99, transition: 'width 0.4s' }} />
                </div>
              </div>
              <div style={{ fontSize: 22, fontWeight: 900, color: '#15803d', minWidth: 50 }}>{total ? Math.round((comp/total)*100) : 0}٪</div>
            </div>
          </div>

          {/* AI rationale — من Gemini */}
          <div style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 16, padding: '16px 18px', display: 'flex', gap: 12 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: '#15803d', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>🤖</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: '#15803d', marginBottom: 5 }}>لماذا هذه الخطة؟</div>

              {aiLoading && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#166534' }}>
                  <span style={{ width: 14, height: 14, borderRadius: '50%', border: '2px solid #bbf7d0', borderTopColor: '#15803d', display: 'inline-block' }} className="spin" />
                  الذكاء الاصطناعي يُنشئ الخطة…
                </div>
              )}

              {!aiLoading && aiError && (
                <div style={{ fontSize: 12, color: '#dc2626' }}>{aiError}</div>
              )}

              {!aiLoading && !aiError && aiPlan && (
                <>
                  <p style={{ margin: 0, fontSize: 12, color: '#166534', lineHeight: 1.7 }}>{aiPlan.reason}</p>
                  <div style={{ fontSize: 12, color: '#166534', marginTop: 8 }}><strong>الهدف: </strong>{aiPlan.goal}</div>
                </>
              )}
            </div>
          </div>

          {/* Weeks — من Gemini */}
          {!aiLoading && !aiError && aiPlan?.weeks?.map((wk, wi) => (
            <div key={wi} style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border-light)', background: '#fafafa', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>الأسبوع {wk.week} — {wk.title}</div>
                <div style={{ fontSize: 11, color: '#9ca3af' }}>{wk.activities.length} أنشطة</div>
              </div>
              <div style={{ padding: '10px 16px 14px' }}>
                <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>{wk.objective}</div>
                {wk.activities.map((act, ai) => {
                  const key = `${sel}-${wi}-${ai}`
                  const isDone = done.has(key)
                  return (
                    <div key={ai} style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 10, padding: '11px 14px', borderRadius: 11, background: isDone ? '#f0fdf4' : '#fafafa', border: `1px solid ${isDone ? '#bbf7d0' : '#f3f4f6'}`, opacity: isDone ? 0.75 : 1, transition: 'all 0.15s' }}>
                      <button onClick={() => toggle(key)} style={{ width: 22, height: 22, borderRadius: '50%', border: `2px solid ${isDone ? '#15803d' : '#d1d5db'}`, background: isDone ? '#15803d' : 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {isDone && <span style={{ color: 'white', fontSize: 11 }}>✓</span>}
                      </button>
                      <div style={{ flex: 1, fontSize: 13, fontWeight: 700, color: isDone ? '#15803d' : '#374151' }}>{act}</div>
                    </div>
                  )
                })}
                <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 12 }}><strong>التقييم: </strong>{wk.assessment}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}