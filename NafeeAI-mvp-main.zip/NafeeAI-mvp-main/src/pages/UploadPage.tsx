import { useState, useRef } from 'react'
import type { Page } from '../App'

interface Props { onNav: (p: Page) => void }

interface UFile { name: string; size: string; status: 'قيد الانتظار' | 'يعالج' | 'محلل' }

// ── ملفات تجريبية ──
const initial: UFile[] = [
  { name: 'khalid_mohammed_angles.pdf',   size: '١.٢ م.ب', status: 'محلل' },
  { name: 'ghida_saad_fractions.jpg',      size: '٣.٤ م.ب', status: 'محلل' },
  { name: 'khalid_mohammed_triangles.pdf', size: '٨٩٢ ك.ب', status: 'يعالج' },
]

const sc = (s: UFile['status']) =>
  s === 'محلل'       ? { bg: '#f0fdf4', c: '#15803d' } :
  s === 'يعالج'      ? { bg: '#fffbeb', c: '#d97706' } :
                       { bg: '#f3f4f6', c: '#6b7280'  }

export default function UploadPage({ onNav }: Props) {
  const [files, setFiles] = useState<UFile[]>(initial)
  const [drag, setDrag] = useState(false)
  const [cls, setCls] = useState('الصف الثامن — الفترة الثانية')
  const ref = useRef<HTMLInputElement>(null)
  const allDone = files.length > 0 && files.every(f => f.status === 'محلل')

  const add = (raw: File[]) => {
    const nf: UFile[] = raw.map(f => ({
      name: f.name,
      size: f.size > 1e6 ? `${(f.size/1e6).toFixed(1)} م.ب` : `${Math.round(f.size/1000)} ك.ب`,
      status: 'قيد الانتظار',
    }))
    setFiles(p => [...p, ...nf])
    setTimeout(() => setFiles(p => p.map(f => f.status === 'قيد الانتظار' ? { ...f, status: 'يعالج' } : f)), 600)
    setTimeout(() => setFiles(p => p.map(f => f.status === 'يعالج' ? { ...f, status: 'محلل' } : f)), 2800)
  }

  return (
    <>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg) } }
        .spin { animation: spin 0.8s linear infinite }
      `}</style>
      <div style={{ padding: '28px 32px', maxWidth: 820, margin: '0 auto', fontFamily: 'Cairo, sans-serif' }}>
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontSize: 24, fontWeight: 900, color: '#0d1f15', margin: 0 }}>رفع الواجبات</h1>
          <p style={{ fontSize: 13, color: '#6b7280', margin: '6px 0 0', lineHeight: 1.7 }}>
            ارفعي ملفات PDF أو صور إجابات الطلاب. يستخرج الذكاء الاصطناعي الإجابات ويحدد الفجوات تلقائياً.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <label style={{ fontSize: 13, fontWeight: 700, color: '#374151' }}>الفصل</label>
          <select value={cls} onChange={e => setCls(e.target.value)} style={{ fontSize: 13, padding: '8px 12px', borderRadius: 10, border: '1px solid var(--border)', background: '#fff', fontFamily: 'Cairo, sans-serif', color: '#111827', outline: 'none' }}>
            <option>الصف الثامن — الفترة الثانية</option>
            <option>الصف الثامن — الفترة الرابعة</option>
            <option>الصف السابع — المتميزون</option>
          </select>
        </div>

        {/* Drop zone */}
        <div
          onClick={() => ref.current?.click()}
          onDragOver={e => { e.preventDefault(); setDrag(true) }}
          onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); add(Array.from(e.dataTransfer.files)) }}
          style={{ borderRadius: 18, border: `2px dashed ${drag ? '#15803d' : '#d1d5db'}`, background: drag ? '#f0fdf4' : '#fafafa', padding: '44px 24px', textAlign: 'center', cursor: 'pointer', transition: 'all 0.15s', marginBottom: 20 }}>
          <input ref={ref} type="file" multiple accept=".pdf,image/*" style={{ display: 'none' }} onChange={e => { if (e.target.files) add(Array.from(e.target.files)) }} />
          <div style={{ fontSize: 36, marginBottom: 10 }}>📤</div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#374151' }}>اسحبي الملفات هنا أو اضغطي للاختيار</div>
          <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 6 }}>PDF وصور (JPG, PNG, HEIC) · حتى ٥٠ ملف</div>
        </div>

        {/* File list */}
        {files.length > 0 && (
          <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
            <div style={{ padding: '11px 18px', borderBottom: '1px solid var(--border-light)', background: '#fafafa', display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 700, color: '#6b7280' }}>
              <span>{files.length} ملف</span>
              <span style={{ color: '#15803d' }}>{files.filter(f => f.status === 'محلل').length} محلل</span>
            </div>
            {files.map((f, i) => {
              const s = sc(f.status)
              return (
                <div key={i} style={{ padding: '13px 18px', borderBottom: i < files.length - 1 ? '1px solid var(--border-light)' : 'none', display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
                    {f.name.endsWith('.pdf') ? '📑' : '🖼'}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', direction: 'ltr', textAlign: 'right' }}>{f.name}</div>
                    <div style={{ fontSize: 11, color: '#9ca3af' }}>{f.size}</div>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: '4px 10px', borderRadius: 99, background: s.bg, color: s.c, whiteSpace: 'nowrap' }}>{f.status}</span>
                </div>
              )
            })}
          </div>
        )}

        {/* AI status banner */}
        {files.length > 0 && (
          allDone ? (
            <div style={{ marginTop: 16, background: 'linear-gradient(135deg,#f0fdf4,#dcfce7)', border: '1px solid #bbf7d0', borderRadius: 16, padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: '#15803d', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0, fontWeight: 900 }}>✓</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#15803d' }}>اكتمل التحليل بالذكاء الاصطناعي</div>
                <div style={{ fontSize: 12, color: '#166534', marginTop: 2 }}>تم استخراج الإجابات وربطها بالمنهج وتحديد فجوات التعلم.</div>
              </div>
              <button onClick={() => onNav('analytics')} style={{ background: '#15803d', color: 'white', border: 'none', borderRadius: 11, padding: '11px 20px', fontFamily: 'Cairo, sans-serif', fontSize: 13, fontWeight: 800, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                عرض تحليل الفصل ←
              </button>
            </div>
          ) : (
            <div style={{ marginTop: 16, background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 16, padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 18, height: 18, borderRadius: '50%', border: '2.5px solid #fde68a', borderTopColor: '#d97706', flexShrink: 0 }} className="spin" />
              <div>
                <div style={{ fontSize: 13, fontWeight: 800, color: '#92400e' }}>الذكاء الاصطناعي يحلل الإجابات…</div>
                <div style={{ fontSize: 12, color: '#92400e', marginTop: 2 }}>يستخرج الإجابات ويربطها بمواضيع المنهج لتحديد فجوات التعلم.</div>
              </div>
            </div>
          )
        )}

        {/* Tips */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, marginTop: 20 }}>
          {[
            { icon: '🔍', t: 'تعرف تلقائي', d: 'يقرأ الذكاء الاصطناعي الإجابات المطبوعة والمكتوبة بخط اليد.' },
            { icon: '🧠', t: 'ربط بالمنهج', d: 'كل سؤال يُربط تلقائياً بالموضوع المناسب في المنهج.' },
            { icon: '📊', t: 'تحليل فوري', d: 'النتائج تظهر في تحليل الفصل خلال دقيقتين من الرفع.' },
          ].map(tip => (
            <div key={tip.t} style={{ background: '#fff', borderRadius: 14, padding: '16px 14px', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: 22, marginBottom: 8 }}>{tip.icon}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#111827', marginBottom: 5 }}>{tip.t}</div>
              <div style={{ fontSize: 12, color: '#6b7280', lineHeight: 1.6 }}>{tip.d}</div>
            </div>
          ))}
        </div>
      </div>
    </>
  )
}